you need .env
you need flag.txt