import falcon
import json


class WelcomeResource(object):
    def on_get(self, req, res):
        """Handles all GET requests."""
        res.status = falcon.HTTP_200  # This is the default status
        res.body = "please post present into big-sock!"


class FlagResource(object):
    def on_post(self, req, res):
        """Handles all POST requests."""
        res.status = falcon.HTTP_200
        body = req.stream.read()
        data = json.loads(body)
        present = data["present"]
        with open(".env") as f:
            password = f.read()
        if present == password:
            with open("flag.txt") as f:
                s = "correct " + f.read()
            res.body = s
        else:
            res.body = "incorrect"


# Create the Falcon application object
app = falcon.API()

# Instantiate the TestResource class
root = WelcomeResource()
flagPage = FlagResource()

# Add a route to serve the resource
app.add_route("/", root)
app.add_route("/big-sock", flagPage)
